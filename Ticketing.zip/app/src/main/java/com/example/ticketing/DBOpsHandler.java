package com.example.ticketing;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class DBOpsHandler extends SQLiteOpenHelper {

    private static final String CREATE_WALLET_TABLE =
            "CREATE TABLE " + Wallet.TABLE_NAME + "("
                    + BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                    + Wallet.COLUMN_USER + " TEXT,"
                    + Wallet.COLUMN_AMOUNT + " DOUBLE "
                    + ")";

    private static final String CREATE_TICKET_TABLE =
            "CREATE TABLE " + Ticket.TABLE_NAME + "("
                    + BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                    + Ticket.COLUMN_USER + " TEXT,"
                    + Ticket.COLUMN_PRICE + " DOUBLE,"
                    + Ticket.COLUMN_TYPE + " TEXT NOT NULL,"
                    + Ticket.COLUMN_SOURCE + " TEXT NOT NULL,"
                    + Ticket.COLUMN_DESTINATION + " TEXT NOT NULL"
                    + ")";

    DBOpsHandler(Context context, String name, int version) {
        super(context, name, null, version);
    }

    public void deleteWallet(String user) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Wallet.TABLE_NAME, Wallet.COLUMN_USER + " = ?", new String[]{user});
        db.close();
    }

    public void deleteUserTickets(String user) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(Ticket.TABLE_NAME, Ticket.COLUMN_USER + " = ?", new String[]{user});
        db.close();
    }

    public void createWallet(String user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Wallet.COLUMN_USER, user);
        values.put(Wallet.COLUMN_AMOUNT, 100.0);
        db.insert(Wallet.TABLE_NAME, null, values);
        db.close();
    }

    public double getMoney(String user) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(Wallet.TABLE_NAME, new String[]{Wallet.COLUMN_AMOUNT}, Wallet.COLUMN_USER + " = ?", new String[]{user}, null, null, null);
        double amount = 0.0;
        while (cursor.moveToNext()) {
            amount = cursor.getDouble(cursor.getColumnIndex(Wallet.COLUMN_AMOUNT));
        }
        cursor.close();
        return amount;
    }

    public boolean addMoneyToWallet(String user, double money) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(Wallet.TABLE_NAME, new String[]{Wallet.COLUMN_AMOUNT}, Wallet.COLUMN_USER + " = ?", new String[]{user}, null, null, null);
        double amount = 0.0;
        while (cursor.moveToNext()) {
            amount = cursor.getDouble(cursor.getColumnIndex(Wallet.COLUMN_AMOUNT));
        }
        cursor.close();
        ContentValues values = new ContentValues();
        values.put(Wallet.COLUMN_AMOUNT, amount + money);
        return db.update(Wallet.TABLE_NAME, values, Wallet.COLUMN_USER + " = ?", new String[]{user}) > 0;
    }

    public boolean removeMoneyFromWallet(String user, double money) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(Wallet.TABLE_NAME, new String[]{Wallet.COLUMN_AMOUNT}, Wallet.COLUMN_USER + " = ?", new String[]{user}, null, null, null);
        double amount = 0.0;
        while (cursor.moveToNext()) {
            amount = cursor.getDouble(cursor.getColumnIndex(Wallet.COLUMN_AMOUNT));
        }
        if (!(amount - money >= 0.0)) {
            return false;
        }
        cursor.close();
        ContentValues values = new ContentValues();
        values.put(Wallet.COLUMN_AMOUNT, amount - money);
        return db.update(Wallet.TABLE_NAME, values, Wallet.COLUMN_USER + " = ?", new String[]{user}) > 0;
    }

    public long addTicket(String user, String type, double price, String source, String destination) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Ticket.COLUMN_USER, user);
        values.put(Ticket.COLUMN_TYPE, type);
        values.put(Ticket.COLUMN_PRICE, price);
        values.put(Ticket.COLUMN_SOURCE, source);
        values.put(Ticket.COLUMN_DESTINATION, destination);
        return db.insert(Ticket.TABLE_NAME, null, values);

    }

    public String retrieveTicket(long ticketId) {
        StringBuilder builder = new StringBuilder();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Ticket.TABLE_NAME, null, BaseColumns._ID + " = ?", new String[]{String.valueOf(ticketId)}, null, null, null);
        while (cursor.moveToNext()) {
            builder.append(cursor.getLong(cursor.getColumnIndex(BaseColumns._ID)));
            builder.append("|");
            builder.append(cursor.getString(cursor.getColumnIndex(Ticket.COLUMN_USER)));
            builder.append("|");
            builder.append(cursor.getString(cursor.getColumnIndex(Ticket.COLUMN_TYPE)));
            builder.append("|");
            builder.append(cursor.getDouble(cursor.getColumnIndex(Ticket.COLUMN_PRICE)));
            builder.append("|");
            builder.append(cursor.getString(cursor.getColumnIndex(Ticket.COLUMN_SOURCE)));
            builder.append("|");
            builder.append(cursor.getString(cursor.getColumnIndex(Ticket.COLUMN_DESTINATION)));
        }
        cursor.close();
        db.close();
        return builder.toString();
    }

    public Cursor retrieveTicketOfUser(String user) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(Ticket.TABLE_NAME, null, Ticket.COLUMN_USER + " = ?", new String[]{user}, null, null, null);
    }


    public void resetDatabase(String user) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Wallet.TABLE_NAME, Wallet.COLUMN_USER + " = ?", new String[]{user});
        db.delete(Ticket.TABLE_NAME, Ticket.COLUMN_USER + " = ?", new String[]{user});
        db.delete("SQLITE_SEQUENCE", "NAME = ?", new String[]{Wallet.TABLE_NAME});
        db.delete("SQLITE_SEQUENCE", "NAME = ?", new String[]{Ticket.TABLE_NAME});
        db.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_WALLET_TABLE);
        db.execSQL(CREATE_TICKET_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
