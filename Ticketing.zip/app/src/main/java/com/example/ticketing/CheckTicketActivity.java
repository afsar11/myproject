package com.example.ticketing;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class CheckTicketActivity extends AppCompatActivity {

    AppCompatTextView idView;
    AppCompatTextView priceView;
    AppCompatTextView typeView;
    AppCompatImageView qrView;
    AppCompatTextView sourceView;
    AppCompatTextView destinationView;

    static boolean init = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_ticket);

        if (!init) {
            scan();
        }

        idView = findViewById(R.id.id_view);
        priceView = findViewById(R.id.price_view);
        typeView = findViewById(R.id.type_view);
        sourceView = findViewById(R.id.source_view);
        destinationView = findViewById(R.id.destination_view);
        qrView = findViewById(R.id.qr_view);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Invalid Ticket", Toast.LENGTH_LONG).show();
            } else {
                String[] ticketDetails = result.getContents().split("\\|");
                idView.setText("ID: " + ticketDetails[0]);
                typeView.setText("Type: " + ticketDetails[2]);
                priceView.setText(String.format("Price: %.2f", Double.parseDouble(ticketDetails[3])));
                sourceView.setText("From: " + ticketDetails[4]);
                destinationView.setText("To: " + ticketDetails[5]);

                try {
                    BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                    Bitmap bitmap = barcodeEncoder.encodeBitmap(result.getContents(), BarcodeFormat.QR_CODE, 512, 512);
                    qrView.setImageBitmap(bitmap);
                } catch (WriterException e) {
                    e.printStackTrace();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void scan() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
        integrator.setPrompt("Scan QR Code");
        integrator.setBeepEnabled(true);
        integrator.setOrientationLocked(false);
        integrator.initiateScan();
        init = true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = new MenuInflater(CheckTicketActivity.this);
        inflater.inflate(R.menu.menu_checker, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_rescan) {
            scan();
        }
        return super.onOptionsItemSelected(item);
    }
}
