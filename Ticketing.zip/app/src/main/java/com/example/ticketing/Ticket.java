package com.example.ticketing;

/**
 * Created by kartik
 * Project Name: Ticketing
 * Package: com.example.ticketing
 * <p>
 * Update History:
 * Created on 18 Apr, 2018 at 3:22 PM by kartik
 */
public class Ticket {

    public static String TABLE_NAME = "ticket";
    public static String COLUMN_USER = "email";
    public static String COLUMN_TYPE = "ticket_type";
    public static String COLUMN_PRICE = "ticket_price";
    public static String COLUMN_SOURCE = "ticket_source";
    public static String COLUMN_DESTINATION = "ticket_destination";
}
