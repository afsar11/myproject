package com.example.ticketing;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        AppCompatTextView idView = findViewById(R.id.id_view);
        AppCompatTextView priceView = findViewById(R.id.price_view);
        AppCompatTextView typeView = findViewById(R.id.type_view);
        AppCompatTextView sourceView = findViewById(R.id.source_view);
        AppCompatTextView destinationView = findViewById(R.id.destination_view);
        AppCompatImageView qrView = findViewById(R.id.qr_view);

        long ticketId = getIntent().getLongExtra(BaseColumns._ID, -1);
        DBOpsHandler dbOpsHandler = new DBOpsHandler(DetailActivity.this, getString(R.string.db_name), 1);
        String ticket = dbOpsHandler.retrieveTicket(ticketId);
        String[] ticketDetails = ticket.split("\\|");
        Log.i("TIC", ticket);

        idView.setText("ID: " + ticketDetails[0]);
        typeView.setText("Type: " + ticketDetails[2]);
        priceView.setText(String.format("Price: %.2f", Double.parseDouble(ticketDetails[3])));
        sourceView.setText("From: " + ticketDetails[4]);
        destinationView.setText("To: " + ticketDetails[5]);

        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.encodeBitmap(ticket, BarcodeFormat.QR_CODE, 512, 512);
            qrView.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }
}
