package com.example.ticketing;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class TicketActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);

        findViewById(R.id.logoutId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).getString(Wallet.COLUMN_USER, null);
                SharedPreferences.Editor editor = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).edit();
                editor.putBoolean("LOGGED", false);
                editor.remove(Wallet.COLUMN_USER);
                editor.apply();
                DBOpsHandler dbOpsHandler = new DBOpsHandler(TicketActivity.this, getString(R.string.db_name), 1);
                dbOpsHandler.resetDatabase(user);
                startActivity(new Intent(TicketActivity.this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        findViewById(R.id.walltId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TicketActivity.this, WalletActivity.class));
            }
        });

        findViewById(R.id.btktId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTicketAndStore("Bus Ticket", 2.30);
            }
        });

        findViewById(R.id.mtktId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTicketAndStore("Metro Ticket", 2.50);
            }
        });

        findViewById(R.id.bpassId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTicketAndStore("Bus Pass", 8.50);
            }
        });

        findViewById(R.id.mpassId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTicketAndStore("Metro Pass", 10.00);
            }
        });

        findViewById(R.id.dtlsId).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TicketActivity.this, ListPurchasesActivity.class));
            }
        });
    }

    private void saveTicketAndStore(String type, double price) {
        startActivity(new Intent(TicketActivity.this, BuyActivity.class)
                .putExtra(Ticket.COLUMN_TYPE, type)
                .putExtra(Ticket.COLUMN_PRICE, price));
    }
}
