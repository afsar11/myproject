package com.example.ticketing;

import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;

public class WalletActivity extends AppCompatActivity {

    double amount = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);

        final String email = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).getString(Wallet.COLUMN_USER, null);
        final DBOpsHandler dbOpsHandler = new DBOpsHandler(WalletActivity.this, getString(R.string.db_name), 1);

        amount = dbOpsHandler.getMoney(email);
        ((AppCompatTextView) findViewById(R.id.email_view)).setText(email);
        final AppCompatTextView amountText = findViewById(R.id.amount_view);
        amountText.setText(String.format("Amount: %.2f", amount));

        final TextInputLayout addMoney = findViewById(R.id.add_money_input);

        findViewById(R.id.add_money).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String money = addMoney.getEditText().getText().toString();
                double addAmount = Double.parseDouble(money);
                dbOpsHandler.addMoneyToWallet(email, addAmount);
                amount = dbOpsHandler.getMoney(email);
                amountText.setText(String.format("Amount: %.2f", amount));
                addMoney.getEditText().setText(null);
            }
        });

    }
}
