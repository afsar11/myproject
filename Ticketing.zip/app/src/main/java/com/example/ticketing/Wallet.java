package com.example.ticketing;

/**
 * Created by kartik
 * Project Name: Ticketing
 * Package: com.example.ticketing
 * <p>
 * Update History:
 * Created on 18 Apr, 2018 at 1:37 PM by kartik
 */
public class Wallet {
    public static final String TABLE_NAME = "wallet";

    public static final String COLUMN_USER = "user_email";
    public static final String COLUMN_AMOUNT = "amount";
}
