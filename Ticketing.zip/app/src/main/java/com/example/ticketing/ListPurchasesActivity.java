package com.example.ticketing;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ListPurchasesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_purchases);

        RecyclerView purchasesRecyclerView = findViewById(R.id.purchases_recycler_view);

        String user = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).getString(Wallet.COLUMN_USER, null);
        DBOpsHandler dbOpsHandler = new DBOpsHandler(ListPurchasesActivity.this, getString(R.string.db_name), 1);
        Cursor allTickets = dbOpsHandler.retrieveTicketOfUser(user);
        purchasesRecyclerView.setLayoutManager(new LinearLayoutManager(ListPurchasesActivity.this));
        purchasesRecyclerView.setAdapter(new AllTicketsAdapter(allTickets));
        purchasesRecyclerView.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener());

    }


    private class AllTicketsAdapter extends RecyclerView.Adapter<AllTicketsAdapter.TicketViewHolder> {

        private Cursor cursor;

        public AllTicketsAdapter(Cursor cursor) {
            this.cursor = cursor;
        }

        @NonNull
        @Override
        public TicketViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ticket_item, parent, false);
            TicketViewHolder holder = new TicketViewHolder(view);
            view.setTag(holder);
            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull TicketViewHolder holder, int position) {
            cursor.moveToPosition(position);
            holder.itemTypeView.setText(cursor.getString(cursor.getColumnIndex(Ticket.COLUMN_TYPE)));
            holder.itemPriceView.setText(String.format("%.2f", cursor.getDouble(cursor.getColumnIndex(Ticket.COLUMN_PRICE))));
            holder.ticketId = cursor.getLong(cursor.getColumnIndex(BaseColumns._ID));
        }

        @Override
        public int getItemCount() {
            return cursor.getCount();
        }

        class TicketViewHolder extends RecyclerView.ViewHolder {

            AppCompatTextView itemTypeView;
            AppCompatTextView itemPriceView;
            long ticketId;

            TicketViewHolder(View itemView) {
                super(itemView);
                itemTypeView = itemView.findViewById(R.id.item_type_view);
                itemPriceView = itemView.findViewById(R.id.item_price_view);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(ListPurchasesActivity.this, DetailActivity.class)
                                .putExtra(BaseColumns._ID, ticketId));
                    }
                });
            }
        }
    }
}

