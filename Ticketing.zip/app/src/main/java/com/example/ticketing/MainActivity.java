package com.example.ticketing;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.BaseTransientBottomBar;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean logged = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).getBoolean("LOGGED", false);
        if (logged) {
            startActivity(new Intent(MainActivity.this, TicketActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
        } else {
            setContentView(R.layout.activity_main);

            final TextInputLayout emailInput = findViewById(R.id.email_input);
            final TextInputLayout passwordInput = findViewById(R.id.password_input);


            findViewById(R.id.sign_in).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String email = emailInput.getEditText().getText().toString();
                    String password = passwordInput.getEditText().getText().toString();

                    if (email.equalsIgnoreCase("test@example.com") && password.equals("TestPassword")) {
                        SharedPreferences.Editor editor = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).edit();
                        editor.putBoolean("LOGGED", true);
                        editor.putString(Wallet.COLUMN_USER, email);
                        editor.apply();
                        DBOpsHandler dbOpsHandler = new DBOpsHandler(MainActivity.this, getString(R.string.db_name), 1);
                        dbOpsHandler.createWallet(email);
                        startActivity(new Intent(MainActivity.this, TicketActivity.class)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    } else {
                        Snackbar.make(v, "Incorrect Credentials", BaseTransientBottomBar.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}
