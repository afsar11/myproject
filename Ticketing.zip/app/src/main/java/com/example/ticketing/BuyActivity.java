package com.example.ticketing;

import android.content.Intent;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.support.design.widget.BaseTransientBottomBar;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class BuyActivity extends AppCompatActivity {

    String source;
    String destination;
    List<String> sourceList;
    List<String> destinationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);

        final String type = getIntent().getStringExtra(Ticket.COLUMN_TYPE);
        final double price = getIntent().getDoubleExtra(Ticket.COLUMN_PRICE, 0.0);
        final String email = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).getString(Wallet.COLUMN_USER, null);
        source = "Place 1";
        destination = "Place 2";

        AppCompatTextView typeView = findViewById(R.id.type_view);
        AppCompatTextView costView = findViewById(R.id.cost_view);
        AppCompatSpinner sourceSpinner = findViewById(R.id.source_spinner);
        final AppCompatSpinner destinationSpinner = findViewById(R.id.destination_spinner);

        sourceList = Arrays.asList(getResources().getStringArray(R.array.stops));

        sourceSpinner.setAdapter(new ArrayAdapter<>(BuyActivity.this, android.R.layout.simple_list_item_1, sourceList));
        sourceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                source = sourceList.get(position);
                destinationList = new LinkedList<String>(Arrays.asList(getResources().getStringArray(R.array.stops)));
                destinationList.remove(source);
                destinationSpinner.setAdapter(new ArrayAdapter<>(BuyActivity.this, android.R.layout.simple_list_item_1, destinationList));
                destinationSpinner.setEnabled(true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        destinationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                destination = destinationList.get(position);
                findViewById(R.id.buy_ticket).setEnabled(true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        typeView.setText("Price of " + type);
        costView.setText(String.format("%.2f", price));

        findViewById(R.id.buy_ticket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBOpsHandler dbOpsHandler = new DBOpsHandler(BuyActivity.this, getString(R.string.db_name), 1);
                if (dbOpsHandler.removeMoneyFromWallet(email, price)) {
                    long ticketId = dbOpsHandler.addTicket(email, type, price, source, destination);
                    startActivity(new Intent(BuyActivity.this, DetailActivity.class)
                            .putExtra(BaseColumns._ID, ticketId));
                } else {
                    Snackbar.make(v, "Insufficient Funds", BaseTransientBottomBar.LENGTH_INDEFINITE)
                            .setAction("Add Money", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    startActivity(new Intent(BuyActivity.this, WalletActivity.class));
                                }
                            })
                            .show();
                }
            }
        });

    }
}
